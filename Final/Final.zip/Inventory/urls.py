# Inventory/urls.py
from django.urls import path
from . import views
from .views import InventoryListView, InventoryCreateView, InventoryUpdateView, InventoryDeleteView
app_name = 'Inventory' 
app_name = 'Items'

urlpatterns = [
    # Inventory routes
    path('inventory/', InventoryListView.as_view(), name='inventory-list'), # Main inventory list
    path('inventory/create/', InventoryCreateView.as_view(), name='inventory-create'), # Create new inventory item
    path('inventory/update/<int:pk>/', InventoryUpdateView.as_view(), name='inventory-update'), # Update existing inventory item
    path('inventory/delete/<int:pk>/', InventoryDeleteView.as_view(), name='inventory-delete'), # Delete inventory item
]
