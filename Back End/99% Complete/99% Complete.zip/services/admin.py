from django.contrib import admin
from .models import ServiceRequest

@admin.register(ServiceRequest)
class ServiceRequestAdmin(admin.ModelAdmin):
    list_display = ('service_name', 'requester', 'registration_date', 'is_completed')
    search_fields = ('service_name', 'requester__username')
    list_filter = ('is_completed', 'registration_date')
