from django.views.generic import ListView, CreateView, UpdateView, DeleteView, TemplateView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from .models import Bill
from .forms import StaffBillForm
from django.shortcuts import redirect


class StaffRequiredMixin:
    def dispatch(self, request, *args, **kwargs):
        if request.user.role != 'staff':  # <-- lowercase check
            return redirect('home')
        return super().dispatch(request, *args, **kwargs)
    
class BillingListView(LoginRequiredMixin, StaffRequiredMixin, ListView):
    model = Bill
    template_name = 'billing/billing_list.html'
    context_object_name = 'bills'

    def get_queryset(self):
        return Bill.objects.all()

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['form'] = StaffBillForm()
        return context


class BillCreateView(LoginRequiredMixin, StaffRequiredMixin, CreateView):
    model = Bill
    form_class = StaffBillForm
    template_name = 'billing/bill_form.html'
    success_url = reverse_lazy('billing:billing-list')

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)


class BillUpdateView(LoginRequiredMixin, StaffRequiredMixin, UpdateView):
    model = Bill
    form_class = StaffBillForm
    template_name = 'billing/bill_form.html'
    success_url = reverse_lazy('billing:billing-list')


class BillDeleteView(LoginRequiredMixin, StaffRequiredMixin, DeleteView):
    model = Bill
    template_name = 'billing/bill_confirm_delete.html'
    success_url = reverse_lazy('billing:billing-list')


class InvoiceView(LoginRequiredMixin, TemplateView):
    template_name = 'billing/invoice.html'

    def dispatch(self, request, *args, **kwargs):
        bill = Bill.objects.get(pk=kwargs['pk'])

        if request.user.role.lower() != 'staff':
            return redirect('billing:billing-list')

        return super().dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['bill'] = Bill.objects.get(pk=self.kwargs['pk'])
        return context


class UserInvoiceView(LoginRequiredMixin, TemplateView):
    template_name = 'billing/user_bills.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['bills'] = Bill.objects.filter(user=self.request.user)
        return context
