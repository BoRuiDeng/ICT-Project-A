from django.urls import path
from .views import BillingListView, BillCreateView, BillUpdateView, BillDeleteView, InvoiceView, UserInvoiceView

app_name = 'billing'

urlpatterns = [
    path('', BillingListView.as_view(), name='billing-list'),
    path('create/', BillCreateView.as_view(), name='billing-create'),
    path('edit/<int:pk>/', BillUpdateView.as_view(), name='edit'),
    path('delete/<int:pk>/', BillDeleteView.as_view(), name='delete'), 
    path('invoice/', UserInvoiceView.as_view(), name='billing-user-invoices'),  # All invoices for current user
    path('invoice/<int:pk>/', InvoiceView.as_view(), name='billing-invoice'),   # Individual invoice
    path('my-bills/', UserInvoiceView.as_view(), name='billing-my-bills'),
]