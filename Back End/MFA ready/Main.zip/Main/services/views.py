from django.contrib.auth.decorators import login_required, user_passes_test
from django.utils.decorators import method_decorator
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from .models import ServiceRequest
from .forms import ServiceRequestForm, StaffServiceRequestForm


def staff_required(user):
    return user.is_staff and not user.is_superuser
# Checks if the user is a staff member but not a superuser.

# Create a decorator for class-based views.
staff_decorator = method_decorator(user_passes_test(staff_required), name='dispatch')

# --- Base View for Staff Operations ---

class StaffServiceViewMixin:
    model = ServiceRequest                       # The main model for service requests.
    form_class = StaffServiceRequestForm         # The form dedicated for staff service requests.
    success_url = reverse_lazy('services:service-list')  # Where to redirect after a successful operation.
# A mixin to supply common configuration for staff service views.

# --- Staff Management Views ---

@staff_decorator
class ServiceListView(ListView):
    model = ServiceRequest                        # Defines the model to list.
    template_name = 'services/service_list.html'  # Template to render the list.
    context_object_name = 'services'              # Name used in the template for the list.

# Displays a list of all service requests for staff review.

@staff_decorator
class ServiceCreateView(StaffServiceViewMixin, CreateView):
    template_name = 'services/service_form.html'  # Template to display the creation form.
# Provides a form for staff members to create a new service request.

@staff_decorator
class ServiceUpdateView(StaffServiceViewMixin, UpdateView):
    template_name = 'services/service_form.html'  # Uses the same template for consistency with creation.
# Allows staff members to update an existing service request.

@staff_decorator
class ServiceDeleteView(DeleteView):
    model = ServiceRequest                           # The service request model to delete.
    template_name = 'services/service_confirm_delete.html'  # Template for deletion confirmation.
    success_url = reverse_lazy('services:service-list')       # Redirect after deletion.
# Enables staff to delete a service request.

# --- Client Submission View ---

@method_decorator(login_required, name='dispatch')
class SubmitServiceRequestView(CreateView):
    model = ServiceRequest                         # Model to store the service request.
    form_class = ServiceRequestForm                # Form for client submissions.
    template_name = 'services/request_form.html'   # Template displaying the service request form.
    success_url = reverse_lazy('services:submit')   # Redirect URL after a successful submission.
#Allows any logged-in user to submit a new service request.
    
    def form_valid(self, form):
        form.instance.requester = self.request.user
        return super().form_valid(form)
# Called when the submitted form is valid. Sets the requester to the currently logged-in user.

    def form_invalid(self, form):
# Called when the form submission is invalid. Adds a generic error message to help the user correct the issue.
        form.add_error(None, "There was an issue submitting your request. Please review the form and try again.")
        return super().form_invalid(form)