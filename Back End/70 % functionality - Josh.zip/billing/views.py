from django.views.generic import ListView, CreateView, UpdateView, DeleteView, TemplateView
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.urls import reverse_lazy
from .models import Bill
from .forms import StaffBillForm
from django.shortcuts import redirect

class BillingListView(LoginRequiredMixin, ListView):
    model = Bill
    template_name = 'billing/billing_list.html'
    context_object_name = 'bills'

    def get_queryset(self):
        if self.request.user.is_staff:
            return Bill.objects.all()
        return Bill.objects.filter(user=self.request.user)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        if self.request.user.is_staff:
            context['form'] = StaffBillForm()
        return context

class BillCreateView(LoginRequiredMixin, CreateView):
    model = Bill
    form_class = StaffBillForm
    template_name = 'billing/bill_form.html'
    success_url = reverse_lazy('billing:billing-list')

    def form_valid(self, form):
        # Automatically assign the bill to the logged-in user
        form.instance.user = self.request.user
        return super().form_valid(form)

class BillUpdateView(UserPassesTestMixin, UpdateView):
    model = Bill
    form_class = StaffBillForm
    template_name = 'billing/bill_form.html'
    success_url = reverse_lazy('billing:billing-list')  # ✅ fixed

    def test_func(self):
        return self.request.user.is_staff

class BillDeleteView(UserPassesTestMixin, DeleteView):
    model = Bill
    template_name = 'billing/bill_confirm_delete.html'
    success_url = reverse_lazy('billing:billing-list')  # ✅ fixed

    def test_func(self):
        return self.request.user.groups.filter(name='Staff').exists()

class InvoiceView(LoginRequiredMixin, TemplateView):
    template_name = 'billing/invoice.html'

    def dispatch(self, request, *args, **kwargs):
        if request.user.is_staff:
            return redirect('billing:billing-list')  # ✅ fixed
        return super().dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['bills'] = Bill.objects.filter(user=self.request.user)
        return context
