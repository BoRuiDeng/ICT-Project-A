from django.urls import path
from .views import (
    BillingListView,
    BillCreateView,
    BillUpdateView,
    BillDeleteView,
    InvoiceView
)

app_name = 'billing'  # Namespacing for reverse_lazy and {% url %} calls

urlpatterns = [
    path('', BillingListView.as_view(), name='billing-list'),
    path('create/', BillCreateView.as_view(), name='billing-create'),
    path('edit/<int:pk>/', BillUpdateView.as_view(), name='billing-edit'),
    path('delete/<int:pk>/', BillDeleteView.as_view(), name='billing-delete'),
    path('invoice/', InvoiceView.as_view(), name='billing-invoice'),
]