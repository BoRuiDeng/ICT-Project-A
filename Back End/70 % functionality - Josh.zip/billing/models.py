from django.db import models
from django.contrib.auth import get_user_model
from django.utils import timezone

User = get_user_model()

class Bill(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField(blank=True, null=True)  # <-- Add this line
    date = models.DateField(default=timezone.now)
    is_paid = models.BooleanField(default=False)  # <-- Ensure this is included

    def __str__(self):
        return f"{self.user.username} - {self.amount} - {'Paid' if self.is_paid else 'Unpaid'}"