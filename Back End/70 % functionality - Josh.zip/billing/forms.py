from django import forms
from .models import Bill
from django.contrib.auth import get_user_model

User = get_user_model()

class StaffBillForm(forms.ModelForm):
    user = forms.ModelChoiceField(queryset=User.objects.all(), label="Assign to User")

    class Meta:
        model = Bill
        fields = ['user', 'amount', 'is_paid']