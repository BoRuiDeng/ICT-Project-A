from django.contrib.auth.decorators import login_required, user_passes_test
from django.utils.decorators import method_decorator
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.shortcuts import redirect
from .models import ServiceRequest
from .forms import ServiceRequestForm, StaffServiceRequestForm

# --- STAFF ONLY SERVICE MANAGEMENT ---

@method_decorator(user_passes_test(lambda u: u.is_staff), name='dispatch')
class ServiceListView(ListView):
    model = ServiceRequest
    template_name = 'services/service_list.html'
    context_object_name = 'services'

@method_decorator(user_passes_test(lambda u: u.is_staff), name='dispatch')
class ServiceCreateView(CreateView):
    model = ServiceRequest
    form_class = StaffServiceRequestForm
    template_name = 'services/service_form.html'
    success_url = reverse_lazy('services:service-list')

@method_decorator(user_passes_test(lambda u: u.is_staff), name='dispatch')
class ServiceUpdateView(UpdateView):
    model = ServiceRequest
    form_class = StaffServiceRequestForm
    template_name = 'services/service_form.html'
    success_url = reverse_lazy('services:service-list')

@method_decorator(user_passes_test(lambda u: u.is_staff), name='dispatch')
class ServiceDeleteView(DeleteView):
    model = ServiceRequest
    template_name = 'services/service_confirm_delete.html'
    success_url = reverse_lazy('services:service-list')


# --- CLIENT/SUBMITTER SERVICE REQUEST FORM ---

@method_decorator(login_required, name='dispatch')
class SubmitServiceRequestView(CreateView):
    model = ServiceRequest
    form_class = ServiceRequestForm
    template_name = 'services/request_form.html'
    success_url = reverse_lazy('services:submit')

    def form_valid(self, form):
        form.instance.requester = self.request.user
        return super().form_valid(form)

    def form_invalid(self, form):
        form.add_error(None, "Something went wrong. Please check your input.")
        return super().form_invalid(form)