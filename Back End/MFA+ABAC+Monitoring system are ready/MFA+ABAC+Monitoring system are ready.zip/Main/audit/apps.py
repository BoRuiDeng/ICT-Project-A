from django.apps import AppConfig

class AuditConfig(AppConfig):
    name = 'audit'

    def ready(self):
        from django.contrib.auth.signals import user_login_failed
        from django.dispatch import receiver
        from .models import AuditLog

        @receiver(user_login_failed)
        def log_failed(sender, credentials, request, **kwargs):
            AuditLog.objects.create(
                user        = None,
                ip_address  = request.META.get('REMOTE_ADDR', ''),
                path        = request.path,
                method      = request.method,
                status_code = 401,
                event_type  = 'login_fail'
            )
