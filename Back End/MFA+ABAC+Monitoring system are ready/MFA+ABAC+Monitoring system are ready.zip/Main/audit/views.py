from django.utils import timezone
from django.views.generic import TemplateView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db.models import Count
from django.db.models.functions import TruncHour
from .models import AuditLog

class AuditDashboardView(LoginRequiredMixin, TemplateView):
    template_name = 'audit/dashboard.html'

    def dispatch(self, request, *args, **kwargs):
        if not request.user.role == 'admin':
            return self.handle_no_permission()
        return super().dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        now      = timezone.now()
        last_day = now - timezone.timedelta(hours=24)

        # 登录失败趋势（按小时聚合）
        login_fail_qs = (
            AuditLog.objects
            .filter(event_type='login_fail', timestamp__gte=last_day)
            .annotate(hour=TruncHour('timestamp'))
            .values('hour')
            .annotate(count=Count('id'))
            .order_by('hour')
        )

        # 同一 IP 访问频次
        ip_dist_qs = (
            AuditLog.objects
            .filter(timestamp__gte=last_day)
            .values('ip_address')
            .annotate(count=Count('id'))
            .order_by('-count')[:20]
        )

        # 404/403 异常增多
        error_qs = (
            AuditLog.objects
            .filter(status_code__in=[403,404], timestamp__gte=last_day)
            .values('status_code')
            .annotate(count=Count('id'))
        )

        # 短时多次登录失败 (>5 次)
        hot_ips = (
            AuditLog.objects
            .filter(event_type='login_fail', timestamp__gte=now - timezone.timedelta(hours=1))
            .values('ip_address')
            .annotate(count=Count('id'))
            .filter(count__gt=5)
        )

        # 非工作时段访问敏感页面
        abnormal_access = (
            AuditLog.objects
            .filter(
                timestamp__hour__lt=9, 
                path__startswith=('/admin/','/billing/','/inventory/','/services/')
            )
            .order_by('-timestamp')[:20]
        )

        return {
            **super().get_context_data(**kwargs),
            'login_fail_trend': list(login_fail_qs),
            'ip_distribution': list(ip_dist_qs),
            'error_stats':     list(error_qs),
            'hot_ips':         list(hot_ips),
            'abnormal':        abnormal_access,
        }
