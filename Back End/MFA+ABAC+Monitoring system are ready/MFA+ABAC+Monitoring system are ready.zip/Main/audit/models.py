from django.conf import settings
from django.db import models

class AuditLog(models.Model):
    timestamp    = models.DateTimeField(auto_now_add=True)
    user         = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL
    )
    ip_address   = models.GenericIPAddressField()
    path         = models.CharField(max_length=200)
    method       = models.CharField(max_length=10)
    status_code  = models.PositiveSmallIntegerField()
    event_type   = models.CharField(
        max_length=30,
        help_text="e.g. login_fail, login_success, forbidden, not_found, view"
    )

    def __str__(self):
        return f"[{self.timestamp}] {self.ip_address} {self.event_type}"
