from django.contrib import admin
from .models import AuditLog

@admin.register(AuditLog)
class AuditLogAdmin(admin.ModelAdmin):
    list_display  = ('timestamp', 'user', 'ip_address', 'path', 'status_code', 'event_type')
    list_filter   = ('event_type', 'status_code', 'timestamp')
    search_fields = ('user__username', 'ip_address', 'path')