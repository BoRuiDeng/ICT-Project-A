from .models import AuditLog

class AuditLoggingMiddleware:

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)

        if not request.path.startswith('/static/'):
            AuditLog.objects.create(
                user        = request.user if request.user.is_authenticated else None,
                ip_address  = request.META.get('REMOTE_ADDR', ''),
                path        = request.path,
                method      = request.method,
                status_code = response.status_code,
                event_type  = self._classify(request, response)
            )
        return response

    def _classify(self, request, response):
        code = response.status_code
        if code == 401:
            return 'login_fail'
        if code == 403:
            return 'forbidden'
        if code == 404:
            return 'not_found'
        return 'view'
