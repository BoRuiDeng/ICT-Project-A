from django.contrib import admin
from.models import Inventory
# Register your models here.

admin.site.register(Inventory)

class InventoryAdmin(admin.ModelAdmin):
    list_display = ('product_name', 'quantity', 'added_in_date', 'expiry_date', 'availability')
    list_filter = ('availability', 'added_in_date')
    search_fields = ('product_name',)
