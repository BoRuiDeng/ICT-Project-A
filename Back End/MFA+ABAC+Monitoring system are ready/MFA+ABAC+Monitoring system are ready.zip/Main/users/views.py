import io
import base64

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth import login, logout, get_user_model
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required

from django_otp.plugins.otp_totp.models import TOTPDevice
import qrcode

from .forms import CustomUserCreationForm


def register_view(request):
    if request.method == "POST":
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('users:my_profile')
    else:
        form = CustomUserCreationForm()
    return render(request, 'users/register.html', {'form': form})


def login_view(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            login(request, form.get_user())
            # after normal login, send them to MFA setup/challenge
            return redirect('users:mfa_setup')
    else:
        form = AuthenticationForm(request)
    return render(request, 'users/login.html', {'form': form})


def logout_view(request):
    if request.method == "POST":
        logout(request)
        return redirect('home')
    return render(request, 'users/logout_confirm.html')


@login_required
def my_profile_view(request):
    return render(request, 'users/my_profile.html')


@login_required
def mfa_setup(request):

    device, created = TOTPDevice.objects.get_or_create(
        user=request.user,
        name='default',
        confirmed=False
    )

    if request.method == 'POST':
        return redirect('users:mfa_verify', pk=device.pk)

    # generate QR code from the otpauth:// URL
    uri = device.config_url
    img = qrcode.make(uri)
    buf = io.BytesIO()
    img.save(buf, format='PNG')
    img_b64 = base64.b64encode(buf.getvalue()).decode()

    return render(request, 'users/mfa_setup.html', {
        'img_data': img_b64,
        'device': device,
    })


@login_required
def mfa_verify(request, pk):

    device = get_object_or_404(
        TOTPDevice,
        pk=pk,
        user=request.user,
        confirmed=False
    )

    error = None
    if request.method == 'POST':
        token = request.POST.get('token')
        if device.verify_token(token):
            device.confirmed = True
            device.save()
            request.session['mfa_verified'] = True
            return redirect('home')
        error = "Invalid code, please try again."

    return render(request, 'users/mfa_verify.html', {'error': error})


@login_required
def mfa_challenge(request):

    device = TOTPDevice.objects.filter(
        user=request.user,
        confirmed=True
    ).first()
    if not device:
        # if they never set one up, force setup first
        return redirect('users:mfa_setup')

    if request.method == 'POST':
        token = request.POST.get('token')
        if device.verify_token(token):
            request.session['mfa_verified'] = True
            return redirect('home')
        messages.error(request, "Invalid code, please try again.")

    return render(request, 'users/mfa_verify.html')
