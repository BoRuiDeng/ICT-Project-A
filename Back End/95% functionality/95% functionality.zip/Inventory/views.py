from django.shortcuts import render
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from .models import Inventory
# Create your views here.

#Inventory Fuction
class InventoryListView(ListView):
    model = Inventory
    template_name = 'Items/inventory_list.html'

class InventoryCreateView(CreateView):
    model = Inventory
    fields = ['product_name', 'quantity', 'added_in_date', 'expiry_date', 'availability']
    template_name = 'Items/inventory_form.html'
    success_url = reverse_lazy('Items:inventory-list')

class InventoryUpdateView(UpdateView):
    model = Inventory
    fields = ['product_name', 'quantity', 'added_in_date', 'expiry_date', 'availability']
    template_name = 'Items/inventory_form.html'
    success_url = reverse_lazy('Items:inventory-list')

class InventoryDeleteView(DeleteView):
    model = Inventory
    template_name = 'Items/inventory_confirm_delete.html'
    success_url = reverse_lazy('Items:inventory-list')

    