from django.contrib.auth.forms import UserCreationForm
from .models import CustomUser

class CustomUserCreationForm(UserCreationForm):

    class Meta(UserCreationForm.Meta):
        model = CustomUser
        # 只用 username、email 两个字段；你也可以加入 'password1','password2'
        fields = ('username', 'email')
