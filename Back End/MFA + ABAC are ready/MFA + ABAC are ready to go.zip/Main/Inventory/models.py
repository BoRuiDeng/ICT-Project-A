from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.db import models
from django.utils import timezone
# Create your models here.

class Inventory(models.Model):
    IN_STOCK = 'in_stock'
    OUT_OF_STOCK = 'out_of_stock'
    LOW_STOCK = 'low_stock'

    AVAILABILITY_CHOICES = [
        (IN_STOCK, 'In Stock'),
        (OUT_OF_STOCK, 'Out of Stock'),
        (LOW_STOCK, 'Low Stock'),
    ]

#Inventory Table
    product_name = models.CharField(max_length=100) # Character field
    quantity = models.PositiveIntegerField() # Integery field
    added_in_date = models.DateField(default=timezone.now) # Date field set to timezone
    expiry_date = models.DateField() # Date field
    availability = models.CharField(
        max_length=20,
        choices=AVAILABILITY_CHOICES,
        default=IN_STOCK
    )

    def __str__(self):
        return f"{self.product_name} ({self.quantity})"