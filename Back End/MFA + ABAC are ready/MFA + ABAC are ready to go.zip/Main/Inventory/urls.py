# Inventory/urls.py
from django.urls import path
from . import views
from .views import InventoryListView, InventoryCreateView, InventoryUpdateView, InventoryDeleteView
app_name = 'Inventory' 

urlpatterns = [
    # Inventory routes
    path('inventory/', InventoryListView.as_view(), name='inventory-list'),
    path('inventory/create/', InventoryCreateView.as_view(), name='inventory-create'),
    path('inventory/update/<int:pk>/', InventoryUpdateView.as_view(), name='inventory-update'),
    path('inventory/delete/<int:pk>/', InventoryDeleteView.as_view(), name='inventory-delete'),
]
