from django.db import models
from django.contrib.auth import get_user_model
from django.utils import timezone

User = get_user_model()

class Bill(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE) # Foreign key linking the bill to a user.
    amount = models.DecimalField(max_digits=10, decimal_places=2)  # Decimal field to store the bill's amount.
    description = models.TextField(blank=True, null=True) # Optional text field for a bill description.
    date = models.DateField(default=timezone.now) # Date field representing when the bill was created.
    is_paid = models.BooleanField(default=False) # Boolean field if the bill is paid.

    def __str__(self):
        return f"{self.user.username} - {self.amount} - {'Paid' if self.is_paid else 'Unpaid'}"
    