from django.contrib import admin
from .models import Bill

@admin.register(Bill)
class BillAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'amount', 'description', 'date', 'is_paid')
    list_filter = ('is_paid', 'date')
    search_fields = ('user__username', 'description')