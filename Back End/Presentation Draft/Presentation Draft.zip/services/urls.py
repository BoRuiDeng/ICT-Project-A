from django.urls import path
from .views import (
    ServiceListView, ServiceCreateView,
    ServiceUpdateView, ServiceDeleteView,
    SubmitServiceRequestView, ServiceDetailView
)

app_name = 'services'

urlpatterns = [
    path('', ServiceListView.as_view(), name='service-list'),
    path('create/', ServiceCreateView.as_view(), name='create'),
    path('edit/<int:pk>/', ServiceUpdateView.as_view(), name='edit'),
    path('delete/<int:pk>/', ServiceDeleteView.as_view(), name='delete'),
    path('submit/', SubmitServiceRequestView.as_view(), name='submit'),
    ######################################
    path('request/<int:pk>/', ServiceDetailView.as_view(), name='request-detail'),
]
