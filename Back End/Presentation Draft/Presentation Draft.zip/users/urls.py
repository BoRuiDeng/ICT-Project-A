from django.urls import path
from . import views
from django.contrib.auth import views as auth_views

app_name = 'users'

urlpatterns = [
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('profile/', views.my_profile_view, name='my_profile'),
    path('mfa-setup/', views.mfa_setup, name='mfa_setup'),
    path('mfa-verify/', views.mfa_verify, name='mfa_verify'),
    path('password-reset/', 
         auth_views.PasswordResetView.as_view(
             template_name='users/password_reset_form.html'
         ),
         name='password_reset'),
    path('password-reset/done/', 
         auth_views.PasswordResetDoneView.as_view(
             template_name='users/password_reset_done.html'
         ),
         name='password_reset_done'),
    path('reset/<uidb64>/<token>/', 
         auth_views.PasswordResetConfirmView.as_view(
             template_name='users/password_reset_confirm.html'
         ),
         name='password_reset_confirm'),
    path('reset/done/', 
         auth_views.PasswordResetCompleteView.as_view(
             template_name='users/password_reset_complete.html'
         ),
         name='password_reset_complete'),
    path('mfa-setup/', views.mfa_setup, name='mfa_setup'),
    path('mfa-verify/<int:pk>/', views.mfa_verify, name='mfa_verify'),
    
    ############################
    path('password-reset/',
     auth_views.PasswordResetView.as_view(
         template_name='users/password_reset_form.html',
         email_template_name='users/password_reset_email.html',  # Add this line
         success_url='/users/password-reset/done/'  # Add this line for clarity
     ),
     name='password_reset'),
]
