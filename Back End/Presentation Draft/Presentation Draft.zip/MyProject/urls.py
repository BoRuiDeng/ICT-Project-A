"""
URL configuration for MyProject project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.contrib import admin
from django.urls import path, include
from .views import homepage, about  
from django.urls import path
from django.contrib.auth import views as auth_views


app_name = "Inventory"
app_name = "services"

urlpatterns = [
    path('admin/', admin.site.urls),
    path('audit/', include('audit.urls', namespace='audit')),
    path('', homepage, name='home'), 
    path('about/', about, name='about'),
    path('users/', include('users.urls', namespace='users')),
    path('inventory/', include('Inventory.urls', namespace='Inventory')),
    path('services/', include('services.urls', namespace='services')),
    path('billing/', include('billing.urls', namespace='billing')),
    
    path('password-reset/',
         auth_views.PasswordResetView.as_view(template_name='users/password_reset_form.html'),
         name='password_reset'),
    path('password-reset/done/',
         auth_views.PasswordResetDoneView.as_view(template_name='users/password_reset_done.html'),
         name='password_reset_done'),
    path('reset/<uidb64>/<token>/',
         auth_views.PasswordResetConfirmView.as_view(template_name='users/password_reset_confirm.html'),
         name='password_reset_confirm'),
    path('reset/done/',
         auth_views.PasswordResetCompleteView.as_view(template_name='users/password_reset_complete.html'),
         name='password_reset_complete'),
]

