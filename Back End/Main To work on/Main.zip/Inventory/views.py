from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from .models import Inventory
# Create your views here.

#Inventory Fuction
class InventoryListView(ListView): # Define a view that lists all inventory items.
    model = Inventory # Specify that the Inventory model is used for this
    template_name = 'Items/inventory_list.html'

class InventoryCreateView(CreateView): # Define a view for creating a new inventory item.
    model = Inventory  # Use the Inventory model for creating a new item.
    fields = ['product_name', 'quantity', 'added_in_date', 'expiry_date', 'availability'] # Specify the list of fields
    template_name = 'Items/inventory_form.html'  # Define the template
    success_url = reverse_lazy('Items:inventory-list') # Redirect to the inventory list view upon successful creation.

class InventoryUpdateView(UpdateView): # Define a view for updating an existing inventory item.
    model = Inventory
    fields = ['product_name', 'quantity', 'added_in_date', 'expiry_date', 'availability']
    template_name = 'Items/inventory_form.html'
    success_url = reverse_lazy('Items:inventory-list')

class InventoryDeleteView(DeleteView): # Define a view for deleting an inventory item.
    model = Inventory
    template_name = 'Items/inventory_confirm_delete.html' # Template for the deletion page
    success_url = reverse_lazy('Items:inventory-list')

    