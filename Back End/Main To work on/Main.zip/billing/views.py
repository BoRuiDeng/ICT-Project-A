from django.views.generic import ListView, CreateView, UpdateView, DeleteView, TemplateView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from .models import Bill
from .forms import StaffBillForm
from django.shortcuts import redirect


class StaffRequiredMixin:
    def dispatch(self, request, *args, **kwargs):
        if request.user.role != 'staff':  # <-- lowercase check / Check if the current user is not a staff member.
            return redirect('home') # If not, redirect them to the home page.
        return super().dispatch(request, *args, **kwargs) # If the user is staff, continue
    
class BillingListView(LoginRequiredMixin, StaffRequiredMixin, ListView):
    model = Bill # Define the model for the list view as Bill.
    template_name = 'billing/billing_list.html'
    context_object_name = 'bills'  # Set the variable.

    def get_queryset(self):
        return Bill.objects.all() # Retrieve and return all Bill objects for listing.
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['form'] = StaffBillForm()
        return context


class BillCreateView(LoginRequiredMixin, StaffRequiredMixin, CreateView):
    model = Bill # Specify that this view creates a new Bill.
    form_class = StaffBillForm # Bill creation form.
    template_name = 'billing/bill_form.html' # Set the template
    success_url = reverse_lazy('billing:billing-list') #redirect 

    def form_valid(self, form):
        return super().form_valid(form) # Proceed


class BillUpdateView(LoginRequiredMixin, StaffRequiredMixin, UpdateView):
    model = Bill # Define the model instance to update.
    form_class = StaffBillForm
    template_name = 'billing/bill_form.html' # Reuse the creation template
    success_url = reverse_lazy('billing:billing-list')


class BillDeleteView(LoginRequiredMixin, StaffRequiredMixin, DeleteView):
    model = Bill # Specify the model that will be deleted.
    template_name = 'billing/bill_confirm_delete.html'
    success_url = reverse_lazy('billing:billing-list')


class InvoiceView(LoginRequiredMixin, TemplateView):
    template_name = 'billing/invoice.html' # Displays an invoice.

    def dispatch(self, request, *args, **kwargs):
        bill = Bill.objects.get(pk=kwargs['pk']) # Retrieve the bill using the primary key from the URL

        if request.user.role.lower() == 'staff':
        # Staff can view any invoice
            return super().dispatch(request, *args, **kwargs)

        if bill.user != request.user:
        # Admins and normal users can only view their OWN invoices
            return redirect('billing:billing-list')

        return super().dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['bill'] = Bill.objects.get(pk=self.kwargs['pk'])
        return context


class UserInvoiceView(LoginRequiredMixin, TemplateView):
    template_name = 'billing/user_bills.html' # Define template that lists invoices for the user.

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs) # Filter and add bills that belong to the current user.
        context['bills'] = Bill.objects.filter(user=self.request.user)
        return context
