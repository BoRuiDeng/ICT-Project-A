from django.db import models
from django.contrib.auth import get_user_model
from django.utils import timezone

User = get_user_model()

class ServiceRequest(models.Model):
    service_name = models.CharField(max_length=100)
    requester = models.ForeignKey(User, on_delete=models.CASCADE)
    registration_date = models.DateTimeField(default=timezone.now)
    is_completed = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.service_name} - {self.requester.username}"
